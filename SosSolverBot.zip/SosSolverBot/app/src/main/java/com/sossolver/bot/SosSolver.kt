package com.sossolver.bot

data class Move(val row: Int, val col: Int, val letter: Char)

class SosSolver {

    private val dirs = listOf(
        0 to 1,   // horizontal
        1 to 0,   // vertical
        1 to 1,   // diagonal \
        1 to -1   // diagonal /
    )

    fun findBestMove(board: Array<CharArray>): Move? {
        val empty = mutableListOf<Pair<Int, Int>>()
        for (r in 0..7) {
            for (c in 0..7) {
                if (board[r][c] == '.') empty.add(r to c)
            }
        }
        if (empty.isEmpty()) return null

        // 1. Prioritas tertinggi: langsung buat SOS (dapat extra turn)
        var bestScore = 0
        var bestMove: Move? = null

        for ((r, c) in empty) {
            for (letter in listOf('S', 'O')) {
                board[r][c] = letter
                val score = countSosAt(board, r, c)
                board[r][c] = '.'
                if (score > bestScore) {
                    bestScore = score
                    bestMove = Move(r, c, letter)
                }
            }
        }
        if (bestScore > 0) return bestMove

        // 2. Blokir ancaman lawan yang bisa langsung SOS
        for ((r, c) in empty) {
            for (letter in listOf('S', 'O')) {
                board[r][c] = letter
                val threat = countSosAt(board, r, c)
                board[r][c] = '.'
                if (threat > 0) {
                    // Blokir dengan huruf lawan dari yang mengancam
                    return Move(r, c, if (letter == 'S') 'O' else 'S')
                }
            }
        }

        // 3. Cari setup ancaman (double threat)
        val setup = findSetupMove(board, empty)
        if (setup != null) return setup

        // 4. Fallback: posisi strategis (dekat tengah)
        return findCenterMove(empty)
    }

    private fun countSosAt(board: Array<CharArray>, r: Int, c: Int): Int {
        var count = 0
        for ((dr, dc) in dirs) {
            for (offset in -2..0) {
                val chars = CharArray(3)
                var valid = true
                for (i in 0..2) {
                    val nr = r + (offset + i) * dr
                    val nc = c + (offset + i) * dc
                    if (nr !in 0..7 || nc !in 0..7) {
                        valid = false
                        break
                    }
                    chars[i] = board[nr][nc]
                }
                if (valid && chars[0] == 'S' && chars[1] == 'O' && chars[2] == 'S') {
                    count++
                }
            }
        }
        return count
    }

    private fun findSetupMove(board: Array<CharArray>, empty: List<Pair<Int, Int>>): Move? {
        // Cari langkah yang menciptakan banyak potensi ancaman
        var bestThreats = 1
        var best: Move? = null

        for ((r, c) in empty) {
            for (letter in listOf('S', 'O')) {
                board[r][c] = letter
                val threats = countPotentialThreats(board)
                board[r][c] = '.'
                if (threats > bestThreats) {
                    bestThreats = threats
                    best = Move(r, c, letter)
                }
            }
        }
        return best
    }

    private fun countPotentialThreats(board: Array<CharArray>): Int {
        var threats = 0
        for (r in 0..7) {
            for (c in 0..7) {
                if (board[r][c] != '.') continue
                for (letter in listOf('S', 'O')) {
                    board[r][c] = letter
                    if (countSosAt(board, r, c) > 0) threats++
                    board[r][c] = '.'
                }
            }
        }
        return threats
    }

    private fun findCenterMove(empty: List<Pair<Int, Int>>): Move {
        val sorted = empty.sortedBy { (r, c) ->
            Math.abs(r - 3.5) + Math.abs(c - 3.5)
        }
        return Move(sorted[0].first, sorted[0].second, 'S')
    }
}
