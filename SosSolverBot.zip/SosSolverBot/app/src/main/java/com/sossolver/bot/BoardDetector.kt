package com.sossolver.bot

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await

class BoardDetector {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    /**
     * PENTING: Sesuaikan koordinat ini dengan posisi papan di HP kamu!
     * Cara: Ambil screenshot game → buka di editor gambar → lihat pixel kiri-atas & kanan-bawah papan hijau.
     * Format: Rect(left, top, right, bottom)
     */
    var boardRect = Rect(80, 250, 1000, 1170)

    suspend fun detect(bitmap: Bitmap): Array<CharArray> {
        val board = Array(8) { CharArray(8) { '.' } }

        val cellW = boardRect.width() / 8
        val cellH = boardRect.height() / 8

        for (r in 0 until 8) {
            for (c in 0 until 8) {
                val left = boardRect.left + c * cellW + 4
                val top = boardRect.top + r * cellH + 4
                val width = cellW - 8
                val height = cellH - 8

                if (left + width > bitmap.width || top + height > bitmap.height) continue

                val cellBmp = Bitmap.createBitmap(bitmap, left, top, width, height)
                board[r][c] = recognizeLetter(cellBmp)
            }
        }
        return board
    }

    private suspend fun recognizeLetter(cell: Bitmap): Char {
        return try {
            val image = InputImage.fromBitmap(cell, 0)
            val result = recognizer.process(image).await()
            val text = result.text.trim().uppercase()

            when {
                text.contains("S") -> 'S'
                text.contains("O") -> 'O'
                else -> '.'
            }
        } catch (e: Exception) {
            '.'
        }
    }

    /** Mengembalikan koordinat tengah sel di layar untuk di-tap */
    fun getScreenCoordinate(row: Int, col: Int): Pair<Float, Float> {
        val cellW = boardRect.width() / 8f
        val cellH = boardRect.height() / 8f
        val x = boardRect.left + col * cellW + cellW / 2f
        val y = boardRect.top + row * cellH + cellH / 2f
        return x to y
    }
}
