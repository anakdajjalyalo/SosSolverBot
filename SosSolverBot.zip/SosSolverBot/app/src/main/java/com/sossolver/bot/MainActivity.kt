package com.sossolver.bot

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val REQUEST_MEDIA_PROJECTION = 1001
    private val REQUEST_OVERLAY = 1002

    private var mediaProjectionResultCode: Int = 0
    private var mediaProjectionData: Intent? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnActivate).setOnClickListener {
            checkAndRequestPermissions()
        }
    }

    private fun checkAndRequestPermissions() {
        // 1. Overlay permission
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan tampil di atas aplikasi lain", Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, REQUEST_OVERLAY)
            return
        }

        // 2. Accessibility reminder
        Toast.makeText(
            this,
            "Pastikan Accessibility Service sudah AKTIF di Settings!",
            Toast.LENGTH_LONG
        ).show()

        // 3. MediaProjection
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQUEST_MEDIA_PROJECTION)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        when (requestCode) {
            REQUEST_OVERLAY -> {
                if (Settings.canDrawOverlays(this)) {
                    checkAndRequestPermissions()
                } else {
                    Toast.makeText(this, "Overlay permission ditolak", Toast.LENGTH_SHORT).show()
                }
            }

            REQUEST_MEDIA_PROJECTION -> {
                if (resultCode == Activity.RESULT_OK && data != null) {
                    mediaProjectionResultCode = resultCode
                    mediaProjectionData = data

                    // Start Overlay
                    startService(Intent(this, OverlayService::class.java))

                    // Start Capture Service dengan permission
                    val captureIntent = Intent(this, ScreenCaptureService::class.java).apply {
                        action = ScreenCaptureService.ACTION_START
                        putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                        putExtra(ScreenCaptureService.EXTRA_DATA, data)
                    }
                    startForegroundService(captureIntent)

                    Toast.makeText(
                        this,
                        "Bot siap! Tekan START di floating overlay",
                        Toast.LENGTH_LONG
                    ).show()

                    // Tutup activity biar tidak mengganggu
                    finish()
                } else {
                    Toast.makeText(this, "Screen capture ditolak", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
