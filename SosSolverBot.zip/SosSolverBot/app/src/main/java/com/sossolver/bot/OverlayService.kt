package com.sossolver.bot

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: android.view.View
    private lateinit var tvStatus: TextView
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button

    companion object {
        var instance: OverlayService? = null
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val inflater = LayoutInflater.from(this)
        overlayView = inflater.inflate(R.layout.overlay_layout, null)

        tvStatus = overlayView.findViewById(R.id.tvStatus)
        btnStart = overlayView.findViewById(R.id.btnStart)
        btnStop = overlayView.findViewById(R.id.btnStop)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 40
        params.y = 180

        windowManager.addView(overlayView, params)

        btnStart.setOnClickListener { startBot() }
        btnStop.setOnClickListener { stopBot() }
    }

    private fun startBot() {
        btnStart.visibility = android.view.View.GONE
        btnStop.visibility = android.view.View.VISIBLE
        tvStatus.text = "Bot Running..."

        val intent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_START
        }
        startForegroundService(intent)
    }

    private fun stopBot() {
        btnStart.visibility = android.view.View.VISIBLE
        btnStop.visibility = android.view.View.GONE
        tvStatus.text = "Stopped"

        val intent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_STOP
        }
        startService(intent)
    }

    fun updateStatus(text: String) {
        tvStatus.post {
            tvStatus.text = text
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        try {
            windowManager.removeView(overlayView)
        } catch (_: Exception) {}
    }
}
