# SOS Solver Bot

Bot otomatis untuk game **SOS 8×8 Multiplayer**.

## Cara Paling Mudah: Generate APK via GitHub Actions

1. Buat repository baru di GitHub (misalnya `SosSolverBot`)
2. Upload **semua isi folder ini** ke repository tersebut
3. Setelah push, buka tab **Actions**
4. Tunggu workflow **Build APK** selesai (status hijau)
5. Klik workflow yang sukses → download artifact **SosSolver-APK**
6. Extract file zip artifact → dapat file `.apk`
7. Install ke HP

> Kamu juga bisa klik tombol **Run workflow** secara manual di tab Actions.

---

## Cara Manual (Android Studio)

1. Buka project ini di Android Studio
2. Sync Gradle
3. Build → Build Bundle(s) / APK(s) → Build APK(s)
4. APK ada di: `app/build/outputs/apk/debug/`

---

## Setup di HP

1. Install APK
2. Buka aplikasi → tekan **AKTIFKAN BOT**
3. Izinkan **Display over other apps**
4. Izinkan **Screen Capture**
5. Buka **Settings → Accessibility** → aktifkan **SOS Solver**
6. Buka game SOS
7. Tekan tombol **START** di floating overlay

---

## Kalibrasi Papan (WAJIB)

Buka file:
`app/src/main/java/com/sossolver/bot/BoardDetector.kt`

Cari baris:
```kotlin
var boardRect = Rect(80, 250, 1000, 1170)
```

Sesuaikan angka `left, top, right, bottom` sesuai posisi papan hijau di HP kamu.

---

## Catatan

- Bot ini melanggar Terms of Service game → risiko akun kena ban
- Akurasi sangat tergantung kalibrasi `boardRect` dan kualitas OCR
- Gunakan dengan tanggung jawab sendiri
